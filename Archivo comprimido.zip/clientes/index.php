<?php
	include_once 'application/Coex.php';

	$coex = Coex::getInstance();
	$coex->invoke();