00C_V1_COEX
===========

Aqui publicaremos el testeo de nuestra app, cada cambio que tengamos que sea funcional, procuren hacer un pull para el commit ... Pregunten cualquier cosa, en el archivo de FAQ...
